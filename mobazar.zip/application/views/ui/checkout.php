
		<div class="w3l_banner_nav_right">
<!-- about -->
		<div class="privacy about">
			<h3>Chec<span>kout</span></h3>
			
	      <div class="checkout-right">
					<h4>Your shopping cart contains: <span><?php echo count($order_data);?> Products</span></h4>
              <form action="<?php echo base_url('dashboard/orders');?>" method="post" class="creditly-card-form agileinfo_form">
				<table class="timetable_sub" id="product_info_table">
					<thead>
						<tr>
							<th>SL No.</th>	
							<th>Product</th>
                            <th>Product Name</th>
							<th>Quantity</th>
						    <th>Price</th>
						</tr>
					</thead>
					<tbody>
                        <?php $x = 1; $tot_qty =0; 
                        foreach($order_data as $k => $v):
    $product = $this->Model_products->getProductDataByname($v['name']);
    $tot_qty = $tot_qty + $v['count'];?>
                        <tr class="rem" id="row_<?php echo $x; ?>">
						<td class="invert"><?php echo $x;?></td>
						<td class="invert-image"><a href="<?php echo base_url('dashboard/single/'.$product['id']);?>"><img src="<?php echo base_url($product['image']);?>" alt="image not found" class="img-responsive"></a></td>
                        <td class="invert"><?php echo $v['name'];?><input type="hidden" name="item_name[]" value="<?php echo $v['name'];?>"></td>
						<td class="invert">
							 <div class="quantity"> 
								<div class="quantity-select"> 
                             <input type="number" name="qty[]" id="qty_<?php echo $x;?>" class="entry value" placeholder=" qty" value="<?php echo $v['count'];?>" readonly>       
								</div>
							</div>
						</td>
						
						<td class="invert">Rs. <?php echo ($v['count'] * $product['price']);?><input type="hidden" name="price[]" value="<?php echo ($v['count'] * $product['price']); ?>"></td>
					</tr>
                        <?php $x++; endforeach; ?>
                        <tr>
                        <td colspan="2">Total</td>
                        <td></td>
                        <td><?php echo $tot_qty;?><input type="hidden" name="tot_qty" value="<?php echo $tot_qty;?>"></td>
                        <td>Rs. <?php echo $order_tot_amt;?> <input type="hidden" name="tot_amt" value="<?php echo $order_tot_amt;?>"></td>
                        </tr>   
				</tbody></table>
			</div>
			<div class="checkout-left">	
				<div class="col-md-12 address_form_agile">
					  <h4>Delivery to this Address</h4>
				
<section class="creditly-wrapper wthree, w3_agileits_wrapper">
        <div class="information-wrapper">
            <div class="first-row form-group">
				<div class=" col-md-6 controls">
				  <label class="control-label">Full name: </label>
                    <input class="billing-address-name form-control" type="text" name="name" placeholder="Full name" value="<?php echo $cust_data['name'];?>" required>
				</div>
				
            <div class="w3_agileits_card_number_grids">
				<div class="w3_agileits_card_number_grid_left">
				    <div class="col-md-6  controls">
				        <label class="control-label">Mobile number:</label>
<input class="form-control" type="text" name="mobile" value="<?php echo $cust_data['mobile'];?>" placeholder="Mobile number" required>
				    </div>
				</div>
                
                <div class="w3_agileits_card_number_grid_right">
				    <div class=" col-md-6  controls">
				        <label class="control-label">Landmark: </label>
            <input class="form-control" name="landmark" type="text" placeholder="Landmark" required>
				    </div>
				</div>
         <div class="clear"> </div>
       </div>

            <div class="col-md-6  controls">
				<label class="control-label">Pincode:</label>
				<input class="form-control" type="text" placeholder="Pincode" name="pincode" value="<?php echo $cust_data['pincode'];?>" required>
            </div>
                <?php if(!isset($shop_id)):
                        $shop_id = 1;
                    endif;?>
                <?php $shop_data = $this->Model_users->getUserData($shop_id);?>
                <div class="col-md-6  controls">
				<label class="control-label">Shop Name:</label>
				<input class="form-control" type="text" placeholder="shop" name="shop_name" value="<?php echo $shop_data['shop_name'];?>" readonly>
				<input class="form-control" type="hidden" placeholder="shop" name="shop_id" value="<?php echo $shop_data['id'];?>" readonly>
            </div>
            
                <div class="col-md-6  controls">
				<label class="control-label">Shop Address:</label>
				<textarea class="form-control"><?php echo $shop_data['address'];?></textarea>
            </div>
                
            <div class="controls">
				<label class="control-label">Address: </label>
				 <textarea class="form-control" name="address" required><?php echo $cust_data['address'];?></textarea>
            </div>
         </div>
<div class="checkout-right-basket">
				        	<button type="submit" name="submit" value="submit" class="btn btn-success clear-cart">Confirm Order <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></button>
			      	</div>
</div>
</section>
</form>
            </div>
			<div class="clearfix"> </div>
            </div>
        </div>
<!-- //about -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo base_url();?>assets_ui/js/move-top.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets_ui/js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->

</body>
</html>