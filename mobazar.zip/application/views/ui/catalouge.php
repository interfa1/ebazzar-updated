
		<div class="w3l_banner_nav_right">
			<div class="w3l_banner_nav_right_banner7">
				<h3>Best Deals For New Products<span class="blink_me"></span></h3>
			</div>
			<div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
				<h3><?php echo $category['cat_name'];?></h3>
				<div class="w3ls_w3l_banner_nav_right_grid1">
					 <?php
                    if(!isset($shop_id)):
                       echo base_url('dashboard/index');
                    endif;
                    foreach ($catlog as $k => $v): ?>
					<div class="col-md-3 w3ls_w3l_banner_left">
						<div class="hover14 column">
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid_pos">
								<img src="<?php echo base_url();?>assets_ui/images/offer.png" alt=" " class="img-responsive" />
							</div>
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block">
										<div class="snipcart-thumb">
											<a href="<?php echo base_url('dashboard/single/'.$v['id']);?>"><img src="<?php echo base_url($v['image']);?>" alt=" " class="img-responsive" /></a>
											<p><?php echo $v['name'];?></p>
											<h4>Rs. <?php echo $v['price'];?></h4>
										</div>
										<div class="snipcart-details">
											<a href="#" data-name="<?php echo $v['name'];?>" data-price="<?php echo $v['price'];?>" data-id="<?php echo $v['id'];?>" class="add-to-cart btn btn-primary">Add to cart</a>				</div>
									</div>
								</figure>
							</div>
						</div>
						</div>
					</div>
                    <?php endforeach; ?>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->
