
<!-- Left Sidebar -->
<aside id="leftsidebar" class="sidebar">
    <div class="menu">
        <ul class="list">
            <li>
                <div class="user-info">
                    <div class="image"><a href="<?php echo base_url('admin/index');?>"><img src="<?php echo base_url();?>assets/images/profile_av.jpg" alt="User"></a></div>
                    <div class="detail">
                        <h4><?php echo $user_data['name'];?></h4>
                        <small><?php echo $user_data['username'];?></small>                        
                    </div>
                    <a href="#" title="Events"><i class="zmdi zmdi-calendar"></i></a>
                    <a href="#" title="Inbox"><i class="zmdi zmdi-email"></i></a>
                    <a href="#" title="Contact List"><i class="zmdi zmdi-account-box-phone"></i></a>
                    <a href="#" title="Chat App"><i class="zmdi zmdi-comments"></i></a>
                    <a href="<?php echo base_url('auth/logout');?>" title="Sign out"><i class="zmdi zmdi-power"></i></a>
                </div>
            </li>
            <li class="header">MAIN</li>
            <li class="active open"> <a href="" class="menu"><i class="zmdi zmdi-home"></i><span>Dashboard</span></a>
            </li>
             <?php if(in_array('updateGroup', $user_permission)||
                    in_array('deleteGroup', $user_permission)||
                    in_array('createGroup', $user_permission)||
                    in_array('viewGroup', $user_permission)): ?> 
            <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-swap-alt"></i><span>Groups</span> </a>
                <ul class="ml-menu">
                <?php if(in_array('createGroup', $user_permission)): ?>
<li> <a href="<?php echo base_url('groups/create');?>">Add Group</a> </li>    
                <?php endif; 
                if(in_array('updateGroup', $user_permission)||
                    in_array('deleteGroup', $user_permission)||
                    in_array('viewGroup', $user_permission)):?>                <li> <a href="<?php echo base_url('groups/');?>">Manage Groups</a> </li>  
                <?php endif; ?>
                </ul>
            </li>
            <?php endif; 
            if(in_array('updateUser', $user_permission)||
                    in_array('deleteUser', $user_permission)||
                    in_array('createUser', $user_permission)||
                    in_array('viewUser', $user_permission)):?>
            <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-apps"></i><span>Users</span> </a>
                <ul class="ml-menu">
    <?php if(in_array('createUser', $user_permission)): ?>
    <li><a href="<?php echo base_url('users/create');?>">Add User</a></li>
                <?php endif; 
                if(in_array('updateUser', $user_permission)||
                    in_array('deleteUser', $user_permission)||
                    in_array('viewUser', $user_permission)):?> 
    <li><a href="<?php echo base_url('users/');?>">Manage Users</a></li>
                 <?php endif; ?>
                </ul>
            </li>
            <?php endif; 
            if(in_array('updateProduct', $user_permission)||
                    in_array('deleteProduct', $user_permission)||
                    in_array('createProduct', $user_permission)||
                    in_array('viewProduct', $user_permission)):?>
            <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-apps"></i><span>Products</span> </a>
                <ul class="ml-menu">
        <?php if(in_array('createProduct', $user_permission)): ?>
<li><a href="<?php echo base_url('products/create');?>">Add Product</a></li>
        <?php endif; 
                if(in_array('updateProduct', $user_permission)||
                    in_array('deleteProduct', $user_permission)||
                    in_array('viewProduct', $user_permission)):?> 
<li><a href="<?php echo base_url('products/');?>">Manage Product</a></li>
                   <?php endif; ?>
                </ul>
            </li>            
            <?php endif; 
            if(in_array('updateOrder', $user_permission)||
                    in_array('deleteOrder', $user_permission)||
                    in_array('createOrder', $user_permission)||
                    in_array('viewOrder', $user_permission)):?>
            <li> <a href="<?php echo base_url('orders/');?>" class="menu-toggle"><i class="zmdi zmdi-apps"></i><span>Manage Orders</span> </a>
            </li>            
            <?php endif; ?> 
            <li class="header">FORMS, CHARTS, TABLES</li>
            <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-assignment"></i><span>Forms</span> </a>
                <ul class="ml-menu">
             <li><a href="#">Products</a> </li>
             <li><a href="#">Shops</a> </li>
               </ul>
            </li>
                     
<!--
            <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-chart"></i><span>Charts</span> </a>
                <ul class="ml-menu">
                    <li> <a href="morris.html">Morris</a> </li>
                    <li> <a href="flot.html">Flot</a> </li>
                    <li> <a href="chartjs.html">ChartJS</a> </li>
                    <li> <a href="sparkline.html">Sparkline</a> </li>
                    <li> <a href="jquery-knob.html">Jquery Knob</a> </li>
                </ul>
            </li>
-->
            
             <li> <a href="<?php echo base_url('admin/signin');?>" class="menu"><i class="zmdi zmdi-power"></i><span>Logout</span></a>
            </li>
            
<!--
            <li> <a href="<?php //echo base_url('dashboard/');?>" class="menu"><i class="zmdi zmdi-apps"></i><span>Web App</span> </a>
            </li> 
-->
           
            <li class="header">Extra</li>
            <li>
                <div class="progress-container progress-primary m-t-10">
                    <span class="progress-badge">Traffic this Month</span>
                    <div class="progress">
                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="67" aria-valuemin="0" aria-valuemax="100" style="width: 67%;">
                            <span class="progress-value">67%</span>
                        </div>
                    </div>
                </div>
                <div class="progress-container progress-info">
                    <span class="progress-badge">Server Load</span>
                    <div class="progress">
                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="86" aria-valuemin="0" aria-valuemax="100" style="width: 86%;">
                            <span class="progress-value">86%</span>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</aside>

<!-- Chat-launcher -->
<!--
<div class="chat-launcher"></div>
<div class="chat-wrapper">
    <div class="card">
        <div class="header">
            <ul class="list-unstyled team-info margin-0">
                <li class="m-r-15"><h2>Design Team</h2></li>
                <li>
                    <img src="<?php //echo base_url();?>assets/images/xs/avatar2.jpg" alt="Avatar">
                </li>
                <li>
                    <img src="<?php //echo base_url();?>assets/images/xs/avatar3.jpg" alt="Avatar">
                </li>
                <li>
                    <img src="<?php// echo base_url();?>assets/images/xs/avatar4.jpg" alt="Avatar">
                </li>
                <li>
                    <img src="<?php// echo base_url();?>assets/images/xs/avatar6.jpg" alt="Avatar">
                </li>
                <li>
                    <a href="javascript:void(0);" title="Add Member"><i class="zmdi zmdi-plus-circle"></i></a>
                </li>
            </ul>                       
        </div>
        <div class="body">
            <div class="chat-widget">
            <ul class="chat-scroll-list clearfix">
                <li class="left float-left">
                    <img src="<?php //echo base_url();?>assets/images/xs/avatar3.jpg" class="rounded-circle" alt="">
                    <div class="chat-info">
                        <a class="name" href="#">Alexander</a>
                        <span class="datetime">6:12</span>                            
                        <span class="message">Hello, John </span>
                    </div>
                </li>
                <li class="right">
                    <div class="chat-info"><span class="datetime">6:15</span> <span class="message">Hi, Alexander<br> How are you!</span> </div>
                </li>
                <li class="right">
                    <div class="chat-info"><span class="datetime">6:16</span> <span class="message">There are many variations of passages of Lorem Ipsum available</span> </div>
                </li>
                <li class="left float-left"> <img src="<?php //echo base_url();?>assets/images/xs/avatar2.jpg" class="rounded-circle" alt="">
                    <div class="chat-info"> <a class="name" href="#">Elizabeth</a> <span class="datetime">6:25</span> <span class="message">Hi, Alexander,<br> John <br> What are you doing?</span> </div>
                </li>
                <li class="left float-left"> <img src="<?php// echo base_url();?>assets/images/xs/avatar1.jpg" class="rounded-circle" alt="">
                    <div class="chat-info"> <a class="name" href="#">Michael</a> <span class="datetime">6:28</span> <span class="message">I would love to join the team.</span> </div>
                </li>
                    <li class="right">
                    <div class="chat-info"><span class="datetime">7:02</span> <span class="message">Hello, <br>Michael</span> </div>
                </li>
            </ul>
            </div>
            <div class="input-group p-t-15">
                <input type="text" class="form-control" placeholder="Enter text here...">
                <span class="input-group-addon">
                    <i class="zmdi zmdi-mail-send"></i>
                </span>
            </div>
        </div>
    </div>
</div>
-->
