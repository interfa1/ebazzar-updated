<?php 


class MY_Controller extends CI_Controller 
{
	public function __construct() 
	{
		parent::__construct();
		$this->load->database();
		
		$this->load->helper('form');
        $this->load->helper('cookie');
		$this->load->library('pagination');
		$this->load->model('Model_auth');
		$this->load->model('Model_groups');
		$this->load->model('Model_users');
		$this->load->model('Model_products');
		$this->load->model('Model_orders');
        
        $group_data = array();
        $this->auto_approval();
        if(empty($this->session->userdata('logged_in'))) {
			$session_data = array('logged_in' => FALSE);
			$this->session->set_userdata($session_data);
		}
        else
        {
            $session_data = $this->session->userdata();
            $this->session_data = $session_data ;
            $data = $this->Model_users->getUserData($session_data['id']);
				$this->data['profile_data'] = array(
						'name' => $data['username'],  						                          'id' => $data['id'],
						'group' => 'System User');
				
			$user_id = $this->session->userdata('id');
			$group_data = $this->Model_groups->getUserGroupByUserId($user_id);
			$this->data['user_data'] = $this->Model_users->getUserData($user_id);
			
			$this->data['user_permission'] = unserialize($group_data['permission']);
			$this->permission = unserialize($group_data['permission']);
			
        }
		
    }
	public function adn_template($page = null, $data = array())
	{
		$this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view($page, $data);
        $this->load->view('templates/footer',$data);
	}
    
    public function ui_template($page = null, $data = array())
	{
		$this->load->view('templates/ui_header',$data);
		//$this->load->view('templates/ui_sidebar',$data);
        $this->load->view($page, $data);
        $this->load->view('templates/ui_footer',$data);
	}
    
     public function logged_in()
	{
		$session_data = $this->session->userdata();
		if($session_data['logged_in'] == TRUE && $session_data['user'] == 'user' ) {
			redirect('admin/', 'refresh');
		}
         else
         {
           redirect('dashboard/', 'refresh');
         }
	}

	public function not_logged_in()
	{
		$session_data = $this->session->userdata();
		if($session_data['logged_in'] == FALSE ) {
			redirect('auth/login', 'refresh');
		}
	}
    
    public function auto_approval()
	{
		$user_data = $this->Model_users->getNotApprovedUserData();
		foreach ($user_data as $k => $v)
		{
			$d1 = $v['created'];
			$d2 = date("Y-m-d h:i:s");
			$datetime1 = new DateTime($d2);
			$datetime2 = new DateTime($d1);
			$interval = $datetime1->diff($datetime2);
			$hour =  $interval->format('%H');
			$day =  $interval->format('%d');
		
			if($hour >= 24 || $day >= 1)
			{
			 	$data = array('approved' => 1,'active' => 1);
				$check = $this->Model_users->edit($data, $v['id']);
			}
		}
	}
	
	
	public function isChecked()
	{
		$user_id = $this->session_data['id'];
		$user_data = $this->Model_users->getUserData($user_id);
		if($user_data['isChecked'] != 1)
		{
		  redirect('users/profile', 'refresh');
		}
	}
	
    
    
   
		
    
}
